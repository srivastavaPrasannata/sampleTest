window.onload = function () {

var options = {
	animationEnabled: false,
		 backgroundColor: "#313131",
		 color: "#fff",
	title: {
		text: "I2V"
	},
	 legend: {
       fontColor: "#fff"
     },
	 toolTip:{
        enabled: false
      },
	data: [{
		type: "doughnut",
		highlightEnabled: false,
		indexLabelFontColor: "#fff",
		innerRadius: "90%",
		showInLegend: false,
		indexLabel: "#percent%",
		indexLabelLineColor: "#313131",
		dataPoints: [
			{  y: 50, indexLabel:"50%" },
			{  y: 15, indexLabel:"15%" },
			{  y: 35, indexLabel:"35%" }
		]
	}]
};
$("#chartContainer").CanvasJSChart(options);

}